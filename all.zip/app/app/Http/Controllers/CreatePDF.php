<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;    

class CreatePDF extends Controller
{
    public function showme(){
        $pdf = \App::make('dompdf.wrapper');
        $pdf->loadHTML('<h1>Adrián mámalo</h1>')->save(storage_path(). 'pdfs'.'/mipdf.pdf');
        return $pdf->stream();
    }
}
